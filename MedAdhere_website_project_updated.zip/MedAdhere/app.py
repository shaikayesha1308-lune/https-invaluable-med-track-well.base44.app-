import sqlite3
from datetime import datetime, date, time
from pathlib import Path
import pandas as pd
import streamlit as st

APP_DIR = Path(__file__).parent
DB_PATH = APP_DIR / "medadhere.db"
st.set_page_config(page_title="MedAdhere | Medication Routine & Refill Companion", page_icon="💊", layout="wide")

def connect():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    with connect() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS medications (
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, strength TEXT DEFAULT '',
            instructions TEXT DEFAULT '', schedule_time TEXT NOT NULL, start_date TEXT NOT NULL,
            stock INTEGER NOT NULL DEFAULT 0, daily_doses INTEGER NOT NULL DEFAULT 1,
            refill_threshold INTEGER NOT NULL DEFAULT 5, created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS dose_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT, medication_id INTEGER NOT NULL,
            scheduled_date TEXT NOT NULL, scheduled_time TEXT NOT NULL,
            status TEXT NOT NULL CHECK(status IN ('Taken','Skipped','Missed')),
            recorded_at TEXT NOT NULL, note TEXT DEFAULT '',
            FOREIGN KEY(medication_id) REFERENCES medications(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS refill_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT, medication_id INTEGER NOT NULL,
            quantity_added INTEGER NOT NULL, added_at TEXT NOT NULL, note TEXT DEFAULT '',
            FOREIGN KEY(medication_id) REFERENCES medications(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS caregiver_permissions (
            id INTEGER PRIMARY KEY AUTOINCREMENT, caregiver_name TEXT NOT NULL,
            caregiver_contact TEXT DEFAULT '', permission_scope TEXT NOT NULL,
            active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL, revoked_at TEXT DEFAULT ''
        );
        """)
        c.commit()

def query(sql, params=()):
    with connect() as c:
        return pd.read_sql_query(sql, c, params=params)

def run(sql, params=()):
    with connect() as c:
        cur = c.execute(sql, params)
        c.commit()
        return cur.lastrowid

def now():
    return datetime.now().isoformat(timespec="seconds")

def meds_df():
    return query("SELECT * FROM medications ORDER BY name")

def active_caregivers():
    return query("SELECT * FROM caregiver_permissions WHERE active=1 ORDER BY caregiver_name")

def add_caregiver(name, contact, scope):
    run("""INSERT INTO caregiver_permissions
        (caregiver_name, caregiver_contact, permission_scope, active, created_at)
        VALUES (?, ?, ?, 1, ?)""", (name.strip(), contact.strip(), scope, now()))

init_db()
st.markdown("""
<style>
.block-container {padding-top:1.5rem; max-width:1250px}
.hero {padding:1.25rem 1.5rem; border-radius:18px; background:linear-gradient(120deg,#e8f5f1,#eef4ff); border:1px solid #d8e8e4}
.hero h1 {margin:0;color:#174f48;font-size:2rem}
.hero p {margin:.4rem 0 0;color:#385c59}
div[data-testid="stMetric"] {border:1px solid #e2e8f0;padding:12px;border-radius:12px;background:#fff}
</style>
""", unsafe_allow_html=True)

with st.sidebar:
    st.markdown("## 💊 MedAdhere")
    st.caption("Medication Routine & Refill Companion")
    page = st.radio("Navigate", ["Dashboard", "My medications", "Dose log", "Refill planner", "Caregiver access", "About & safety"])
    st.divider()
    st.caption("Prototype • Local SQLite database")
    if st.button("Load sample demo data", use_container_width=True):
        if query("SELECT COUNT(*) n FROM medications").iloc[0]["n"] == 0:
            mid = run("""INSERT INTO medications
                (name,strength,instructions,schedule_time,start_date,stock,daily_doses,refill_threshold,created_at)
                VALUES (?,?,?,?,?,?,?,?,?)""",
                ("Example medication", "As prescribed", "Follow clinician/pharmacist instructions.", "08:00", date.today().isoformat(), 4, 1, 5, now()))
            run("""INSERT INTO dose_logs (medication_id,scheduled_date,scheduled_time,status,recorded_at,note)
                   VALUES (?,?,?,?,?,?)""", (mid, date.today().isoformat(), "08:00", "Taken", now(), "Sample demo entry"))
            st.success("Sample medication data added.")
        else:
            st.info("Medication records already exist; sample data was not added.")

st.markdown("""<div class="hero"><h1>💊 MedAdhere</h1>
<p>A calmer way to track medication routines, monitor supplies, and share support—with consent.</p></div>""", unsafe_allow_html=True)
st.write("")
st.info("Safety: This organizer does not prescribe, diagnose, or change medication instructions. Use the schedule provided by a clinician or pharmacist.")

today = date.today()
meds = meds_df()
logs = query("""SELECT dose_logs.*, medications.name AS medication_name FROM dose_logs
                JOIN medications ON medications.id=dose_logs.medication_id
                ORDER BY scheduled_date DESC, scheduled_time DESC""")
caregivers = active_caregivers()

if page == "Dashboard":
    st.subheader("Your routine at a glance")
    low_stock = int((meds["stock"] <= meds["refill_threshold"]).sum()) if not meds.empty else 0
    todays = logs[logs["scheduled_date"] == today.isoformat()] if not logs.empty else logs
    taken = int((todays["status"] == "Taken").sum()) if not todays.empty else 0
    c1,c2,c3,c4 = st.columns(4)
    c1.metric("Medications", len(meds))
    c2.metric("Taken logged today", taken)
    c3.metric("Low-stock alerts", low_stock)
    c4.metric("Active caregivers", len(caregivers))

    st.markdown("### Today's schedule")
    if meds.empty:
        st.info("No medications added yet. Open My medications to add one.")
    else:
        for _, m in meds.sort_values("schedule_time").iterrows():
            with st.container(border=True):
                a,b,c = st.columns([3,2,2])
                a.markdown(f"**{m['name']}**")
                a.caption(f"{m['strength'] or 'Strength not entered'} · {m['instructions'] or 'Follow prescribed instructions'}")
                b.write(f"🕒 {m['schedule_time']}")
                c.write(f"📦 Stock: **{int(m['stock'])}**")
                existing = query("""SELECT status FROM dose_logs WHERE medication_id=? AND scheduled_date=? AND scheduled_time=?
                                    ORDER BY id DESC LIMIT 1""", (int(m["id"]), today.isoformat(), str(m["schedule_time"])))
                st.caption("Today's log: " + existing.iloc[0]["status"] if not existing.empty else "Not logged yet today")

    st.markdown("### Caregiver support")
    st.caption("Add a caregiver directly from the Dashboard. Consent is required before saving the demo permission.")
    with st.expander("＋ Add caregiver from Dashboard", expanded=False):
        with st.form("dashboard_caregiver_form", clear_on_submit=True):
            dash_cg_name = st.text_input("Caregiver name *", key="dash_cg_name")
            dash_cg_contact = st.text_input("Contact (optional)", key="dash_cg_contact", placeholder="Avoid sensitive details in a public demo")
            dash_cg_scope = st.selectbox("Permission scope", [
                "View routine and reminders",
                "View routine and adherence log",
                "View routine, adherence log and refill status"
            ], key="dash_cg_scope")
            dash_cg_consent = st.checkbox("I consent to recording this caregiver permission in this demo.", key="dash_cg_consent")
            dash_cg_submit = st.form_submit_button("Add caregiver", type="primary")
            if dash_cg_submit:
                if not dash_cg_name.strip():
                    st.error("Enter a caregiver name.")
                elif not dash_cg_consent:
                    st.error("Check the consent box before adding the caregiver.")
                else:
                    add_caregiver(dash_cg_name, dash_cg_contact, dash_cg_scope)
                    st.success("Caregiver added to the Dashboard.")
                    st.rerun()
    caregivers = active_caregivers()
    st.caption("Only caregivers with an active demo permission are shown here.")
    if caregivers.empty:
        st.info("No active caregivers yet. Open **Caregiver access** in the sidebar to add a caregiver and record consent.")
        if st.button("Go to Caregiver access", type="primary"):
            st.session_state["navigate_to_caregiver"] = True
            st.rerun()
    else:
        for _, cg in caregivers.iterrows():
            with st.container(border=True):
                a,b,c = st.columns([2,3,1])
                a.markdown(f"**{cg['caregiver_name']}**")
                a.caption(cg["caregiver_contact"] or "No contact entered")
                b.write(cg["permission_scope"])
                b.caption(f"Permission granted: {cg['created_at']}")
                c.success("Active")
        if st.button("Manage caregivers"):
            st.session_state["navigate_to_caregiver"] = True
            st.rerun()

    st.markdown("### Refill attention")
    if low_stock:
        for _, m in meds[meds["stock"] <= meds["refill_threshold"]].iterrows():
            st.warning(f"{m['name']}: {int(m['stock'])} unit(s) left. Alert threshold: {int(m['refill_threshold'])}. Check supply and contact your pharmacy if needed.")
    else:
        st.success("No low-stock alerts based on the thresholds you entered.")
    st.caption("Reminders are shown in the website while it is open. This prototype does not send background push notifications.")

elif page == "My medications":
    st.subheader("My medications")
    st.write("Enter information exactly as provided by your clinician or pharmacist.")
    with st.form("med_form", clear_on_submit=True):
        name = st.text_input("Medication name *")
        strength = st.text_input("Strength (optional)")
        instructions = st.text_area("Label / clinician instructions (optional)")
        col1,col2 = st.columns(2)
        schedule = col1.time_input("Reminder time", value=time(8,0), step=300)
        start = col2.date_input("Start date", value=today)
        col3,col4,col5 = st.columns(3)
        stock = col3.number_input("Current stock (units)", min_value=0, value=0, step=1)
        daily = col4.number_input("Scheduled doses per day", min_value=1, max_value=24, value=1, step=1)
        threshold = col5.number_input("Refill alert at or below", min_value=0, value=5, step=1)
        submit = st.form_submit_button("Save medication", type="primary")
        if submit:
            if not name.strip():
                st.error("Please enter the medication name.")
            else:
                run("""INSERT INTO medications (name,strength,instructions,schedule_time,start_date,stock,daily_doses,refill_threshold,created_at)
                       VALUES (?,?,?,?,?,?,?,?,?)""",
                    (name.strip(), strength.strip(), instructions.strip(), schedule.strftime("%H:%M"), start.isoformat(), int(stock), int(daily), int(threshold), now()))
                st.success("Medication saved.")
                st.rerun()
    meds = meds_df()
    st.markdown("#### Saved medication list")
    if meds.empty:
        st.caption("Nothing saved yet.")
    else:
        st.dataframe(meds[["id","name","strength","schedule_time","start_date","stock","daily_doses","refill_threshold"]], use_container_width=True, hide_index=True)
        options = {f"{r['name']} (ID {r['id']})": int(r["id"]) for _,r in meds.iterrows()}
        label = st.selectbox("Choose medication to update or delete", list(options))
        mid = options[label]
        current = meds[meds["id"] == mid].iloc[0]
        left,right = st.columns(2)
        with left:
            new_stock = st.number_input("Set current stock", min_value=0, value=int(current["stock"]), step=1)
            if st.button("Update stock"):
                run("UPDATE medications SET stock=? WHERE id=?", (int(new_stock), mid))
                st.success("Stock updated.")
                st.rerun()
        with right:
            confirm = st.checkbox("Confirm deleting this medication and its history")
            if st.button("Delete medication", disabled=not confirm):
                run("DELETE FROM medications WHERE id=?", (mid,))
                st.success("Medication deleted.")
                st.rerun()

elif page == "Dose log":
    st.subheader("Adherence log")
    meds = meds_df()
    if meds.empty:
        st.info("Add a medication first.")
    else:
        opts = {f"{r['name']} — {r['schedule_time']}": int(r["id"]) for _,r in meds.iterrows()}
        with st.form("dose_form", clear_on_submit=True):
            label = st.selectbox("Medication", list(opts))
            scheduled_date = st.date_input("Scheduled date", value=today)
            row = meds[meds["id"] == opts[label]].iloc[0]
            scheduled_time = st.time_input("Scheduled time", value=datetime.strptime(str(row["schedule_time"]), "%H:%M").time())
            status = st.radio("Record status", ["Taken","Skipped","Missed"], horizontal=True)
            note = st.text_input("Optional note")
            submit = st.form_submit_button("Save dose log", type="primary")
            if submit:
                run("""INSERT INTO dose_logs (medication_id,scheduled_date,scheduled_time,status,recorded_at,note)
                       VALUES (?,?,?,?,?,?)""",
                    (opts[label], scheduled_date.isoformat(), scheduled_time.strftime("%H:%M"), status, now(), note.strip()))
                st.success(f"Saved: {status}. This is a self-reported entry.")
                st.rerun()
    logs = query("""SELECT dose_logs.id, medications.name AS medication, dose_logs.scheduled_date AS date,
                    dose_logs.scheduled_time AS time, dose_logs.status, dose_logs.recorded_at, dose_logs.note
                    FROM dose_logs JOIN medications ON medications.id=dose_logs.medication_id
                    ORDER BY dose_logs.scheduled_date DESC, dose_logs.scheduled_time DESC""")
    if logs.empty:
        st.caption("No dose entries yet.")
    else:
        st.dataframe(logs, use_container_width=True, hide_index=True)
        st.download_button("Download adherence log (CSV)", logs.to_csv(index=False).encode("utf-8"),
                           "medadhere_dose_log.csv", "text/csv")

elif page == "Refill planner":
    st.subheader("Refill planner")
    meds = meds_df()
    if meds.empty:
        st.info("Add a medication first.")
    else:
        low = meds[meds["stock"] <= meds["refill_threshold"]]
        if low.empty:
            st.success("No medications currently meet their refill alert threshold.")
        else:
            for _, m in low.iterrows():
                st.warning(f"**{m['name']}** — {int(m['stock'])} unit(s) left (threshold: {int(m['refill_threshold'])}).")
        opts = {f"{r['name']} (stock: {int(r['stock'])})": int(r["id"]) for _,r in meds.iterrows()}
        with st.form("refill_form", clear_on_submit=True):
            label = st.selectbox("Medication", list(opts))
            quantity = st.number_input("Quantity added", min_value=1, value=1, step=1)
            note = st.text_input("Optional note")
            submit = st.form_submit_button("Add to stock", type="primary")
            if submit:
                mid = opts[label]
                run("UPDATE medications SET stock=stock+? WHERE id=?", (int(quantity), mid))
                run("INSERT INTO refill_logs (medication_id,quantity_added,added_at,note) VALUES (?,?,?,?)", (mid,int(quantity),now(),note.strip()))
                st.success("Stock updated and refill recorded.")
                st.rerun()
        history = query("""SELECT refill_logs.id, medications.name AS medication, refill_logs.quantity_added,
                           refill_logs.added_at, refill_logs.note FROM refill_logs
                           JOIN medications ON medications.id=refill_logs.medication_id ORDER BY refill_logs.added_at DESC""")
        st.markdown("#### Refill history")
        st.dataframe(history, use_container_width=True, hide_index=True) if not history.empty else st.caption("No refill additions recorded.")

elif page == "Caregiver access":
    st.subheader("Caregiver sharing & consent")
    st.write("Record the user's consent choice in this local demo. This does not authenticate caregiver identities or securely share data online.")
    with st.form("caregiver_form", clear_on_submit=True):
        name = st.text_input("Caregiver name *")
        contact = st.text_input("Contact (optional)", placeholder="Avoid entering sensitive details in a public demo")
        scope = st.selectbox("Permission scope", [
            "View routine and reminders",
            "View routine and adherence log",
            "View routine, adherence log and refill status"
        ])
        consent = st.checkbox("I consent to recording this caregiver permission in this demo.")
        submit = st.form_submit_button("Grant demo permission", type="primary")
        if submit:
            if not name.strip():
                st.error("Enter a caregiver name.")
            elif not consent:
                st.error("Check the consent box before granting permission.")
            else:
                add_caregiver(name, contact, scope)
                st.success("Caregiver permission recorded. The active caregiver now appears on the Dashboard.")
                st.rerun()
    permissions = query("SELECT * FROM caregiver_permissions ORDER BY id DESC")
    st.markdown("#### Permission history")
    if permissions.empty:
        st.caption("No caregiver permissions recorded.")
    else:
        for _, p in permissions.iterrows():
            with st.container(border=True):
                a,b,c = st.columns([3,3,1])
                a.markdown(f"**{p['caregiver_name']}**")
                a.caption(p["caregiver_contact"] or "No contact entered")
                b.write(p["permission_scope"])
                b.caption(f"Granted: {p['created_at']}")
                if int(p["active"]) == 1:
                    c.success("Active")
                    if c.button("Revoke", key=f"revoke_{p['id']}"):
                        run("UPDATE caregiver_permissions SET active=0, revoked_at=? WHERE id=?", (now(), int(p["id"])))
                        st.rerun()
                else:
                    c.write("Revoked")
                    c.caption(p["revoked_at"] or "")

else:
    st.subheader("About & safety")
    st.markdown("""
**Goal:** organize recurring medication routines, notice low supplies, record self-reported dose status, and let users record caregiver consent.

**Included:** schedule dashboard, stock threshold alerts, refill history, adherence log, caregiver permission records and revoke option, local SQLite storage, and CSV export.

**Limitations:** this prototype does not prescribe, diagnose, change doses, verify medication use, send background notifications, or securely share data online. Do not enter real patient data in a public demo.

**Before production:** add authenticated accounts, role-based access enforcement, secure caregiver identity verification, encryption, backup, accessibility testing, and privacy/security and clinical-safety reviews.

Suggested alignment with MoHFW is a proposal only and does not imply official endorsement.
""")
    st.markdown("### Next improvements")
    st.markdown("1. Push notifications with explicit opt-in.  \n2. Secure caregiver accounts and sharing permissions.  \n3. Mobile accessibility and screen-reader testing.  \n4. Automated tests for stock alerts and permission revocation.")
