# MedAdhere: Medication Routine and Refill Companion

## Run on Windows
1. Extract the ZIP and open the `MedAdhere` folder in VS Code.
2. Open Terminal > New Terminal.
3. Create a virtual environment:
   `py -m venv .venv`
4. Activate it in PowerShell:
   `\.venv\Scripts\Activate.ps1`
   If blocked, use Command Prompt and run `\.venv\Scripts\activate.bat`.
5. Install packages: `pip install -r requirements.txt`
6. Start the website: `streamlit run app.py`
7. Open the local URL shown in the terminal, usually http://localhost:8501.

## What's changed
- The Dashboard now includes an **Active caregivers** count and a **Caregiver support** section.
- When a caregiver is added and consent is checked in Caregiver access, the active caregiver appears on the Dashboard.
- Revoking a permission removes that caregiver from the Dashboard's active list, while keeping the history in Caregiver access.

## Features
Medication schedule overview, dose log (Taken/Skipped/Missed), stock threshold refill alerts, refill history, caregiver consent record and revoke option, local SQLite database, and CSV export.

## Important limitations
This is a prototype, not a medical device. It does not prescribe or change prescriptions, verify doses, send background notifications, or securely share data online. Do not enter real patient data in a public demo. Production use requires authentication, permission enforcement, encryption, privacy/security review, and appropriate clinical-safety review.
